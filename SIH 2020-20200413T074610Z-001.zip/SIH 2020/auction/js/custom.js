(function ($, window, document, undefined) {
    'use strict';

    /*
     /*
     * Custom Data Fixed
     */
    $('.beactive').addClass('active');
    $('.beactive').removeClass('beactive');

})(jQuery, window, document);

