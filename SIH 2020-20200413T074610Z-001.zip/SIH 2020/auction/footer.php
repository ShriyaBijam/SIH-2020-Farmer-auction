     <!-- Start Suvbscribe -->
            <div class="news-subscribe">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h3>subscribe to <strong>Crop Auction</strong></h3>
                        </div>
                        <div class="col-md-4 newsletter-form-block">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Email your email...">
                                <span class="input-group-btn">
                                    <button class="btn" type="button"><i class="fa fa-envelope-o"></i></button>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4 col-xs-12">
                            <div class="social-footer">
                                <ul class="social-icons social-icons-simple">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Suvbscribe -->


            <!-- START FOOTER -->
            <footer class="footer">
                <div class="container">
                    <div class="row">
                        <!-- CONTACT WIDGET -->
                           <!-- CATEGORIES WIDGET -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="widget">
                                <h6 class="montserrat text-uppercase bottom-line">Quick Links</h6>
                                <ul class="icons-list">
                                    <li><a href="http://localhost/auction/index.php">Home</a></li>
                                     
                                    <li><a href="http://localhost/auction/customer/topBidder.php">Top Bidders</a></li>
                                    <!--
                                    <li><a href="">Vehicles</a></li>
                                    <li><a href="#">About</a></li>
                                    -->
                                </ul>
                            </div>
                        </div>
                        <!-- END CATEGORIES WIDGET -->
                        <div class="col-md-3 col-sm-6 col-xs-12" style="float: right;">
                            <div class="widget">
                                <h6 class="text-uppercase bottom-line">Contact Us</h6>
                                <address>
                                    <p>Atharva College of Engineering, Malad, Mumbai</p><br>
                                    <p>Phone: 987654321</p>
                                    
                                    <p>E-mail: <a href="mailto:sid3345@gmail.com">sid3345@gmail.com</a></p>
                                </address>
                            </div>
                        </div>
                        <!-- END CONTACT WIDGET -->
 


                     





                    </div>

                    <!-- CONTACT WIDGET -->
                    <div class="copyright">
                        <div class="text-center">
                            <p>© All Rights Reserved @ Siddharth Sinha</p>
                        </div>
                    </div>

                </div>
            </footer>
            <!-- END FOOTER--> 
       
           
        <!-- JQUERY LIBS -->
        <script type="text/javascript"  src="<?=$_SESSION["directory"]?>js/jquery.min.js"></script>
        <!-- BOOTSTRAP -->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/bootstrap.min.js"></script>
        <!-- OWL CAROUSEL -->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>plugins/owl-carousel/owl.carousel.min.js"></script>
        <!-- FLEXSLIDER -->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>plugins/FlexSlider/jquery.flexslider-min.js"></script>
        <!-- MAGNIFIC POPUP-->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/jquery.magnific-popup.min.js"></script>
        <!-- MAGNIFIC POPUP  -->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/magnific-popup.min.js"></script>
                <!-- product-->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/product.js"></script>
         <!-- slick-->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/slick.js"></script>
           <!-- slick-slider-->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/slick-slider.js"></script>
        <!-- plugins-->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/plugins.min.html"></script>

        <!-- CUSTOM-->
        <script type="text/javascript" src="<?=$_SESSION["directory"]?>js/custom.js"></script>

        <!--[if lt IE 9]>
        <script src="respond.js"></script>
        <script src="html5shiv.js"></script>
        <![endif]-->

    </body>